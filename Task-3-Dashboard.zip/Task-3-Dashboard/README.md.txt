# Task 3 – Dashboard Design (Data Analyst Internship)

## 📌 Objective
To design an interactive sales dashboard for stakeholders using cleaned Superstore sales data.

---

## 📊 Dataset
- **File**: `cleaned_superstore_data.csv`
- **Source**: Kaggle (cleaned in Excel/Power BI)
- **Location**: `/dataset/`

---

## 🛠 Tools Used
- Microsoft Power BI
- Excel (for data cleaning)
- GitHub (for version control and submission)

---

## 📈 Key KPIs in the Dashboard
- ✅ Total Sales
- ✅ Total Profit
- ✅ Monthly Sales Trend
- ✅ Category-wise and Region-wise Sales
- ✅ Profit Margin (if applicable)
- ✅ Filters (Region, Category, Date)

---

## 🖼 Dashboard Preview
(Screenshot is available in `/screenshots/`)

---

## 📤 Project Files

| Folder         | Contents                                |
|----------------|------------------------------------------|
| `/dataset/`    | Cleaned dataset CSV                     |
| `/dashboard/`  | Power BI Dashboard PDF                  |
| `/summary/`    | PPT summary of dashboard                |
| `/screenshots/`| Dashboard preview screenshot            |

---

## 💡 How to Use
1. View the Power BI dashboard in `/dashboard/`
2. Apply slicers for Region, Category, or Date (if using interactive version)
3. Refer to PPT in `/summary/` for business insights and overview

---

## ✅ Submission
This project is submitted for Task 3 of the Data Analyst Internship program.

🔗 [Project Repository](https://github.com/vemuri11/Task-3-Dashboard)
